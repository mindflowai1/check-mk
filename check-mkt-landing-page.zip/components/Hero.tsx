import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Star } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Hero: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section id="home" className="relative min-h-screen flex flex-col justify-center items-center overflow-hidden bg-dark-900 pt-32 pb-10">
      
      {/* Background Floating Stars */}
      <motion.div 
        animate={{ y: [0, -20, 0], rotate: [0, 15, 0], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-[15%] left-[10%] text-brand/30 hidden md:block z-0"
      >
        <Star className="w-8 h-8 fill-brand/10" />
      </motion.div>
      
      <motion.div 
        animate={{ y: [0, 20, 0], rotate: [0, -15, 0], opacity: [0.2, 0.5, 0.2] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        className="absolute bottom-[20%] right-[10%] text-white/10 hidden md:block z-0"
      >
        <Star className="w-6 h-6 fill-white/5" />
      </motion.div>

      <div className="container mx-auto px-6 relative z-10 flex flex-col items-center text-center flex-grow justify-center">
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative flex flex-col items-center max-w-5xl mx-auto"
        >
          {/* Subtitle / Tag */}
          <div className="flex items-center gap-4 md:gap-6 mb-8 text-[10px] md:text-xs font-bold tracking-[0.2em] text-gray-500 uppercase">
             <span className="hover:text-brand transition-colors cursor-default">{t.hero.tags[0]}</span>
             <span className="w-1 h-1 bg-gray-700 rounded-full"></span>
             <span className="hover:text-brand transition-colors cursor-default">{t.hero.tags[1]}</span>
             <span className="w-1 h-1 bg-gray-700 rounded-full"></span>
             <span className="hover:text-brand transition-colors cursor-default">{t.hero.tags[2]}</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white leading-[1.1] mb-8 tracking-tight drop-shadow-2xl relative z-10">
            {t.hero.titlePre} <br />
            {t.hero.titleBreak} 
            <span className="relative inline-block ml-3 md:ml-4">
                {/* FOCUSED GLOW - Anchored specifically to 'Realidade' */}
                <motion.div 
                    animate={{ 
                        opacity: [0.4, 0.7, 0.4], 
                        scale: [0.9, 1.1, 0.9],
                    }}
                    transition={{ 
                        duration: 3, 
                        repeat: Infinity, 
                        ease: "easeInOut" 
                    }}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] md:w-[600px] md:h-[450px] bg-brand/30 rounded-full blur-[80px] -z-10 pointer-events-none mix-blend-screen"
                />
                
                {/* Decorative Star attached to the word */}
                <motion.div
                    animate={{ rotate: [0, 10, 0], scale: [1, 1.1, 1] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute -top-4 -right-6 md:-top-8 md:-right-10 text-brand z-20"
                >
                    <Star className="w-8 h-8 md:w-14 md:h-14 fill-brand/20 text-brand drop-shadow-[0_0_15px_rgba(98,174,136,0.8)]" />
                </motion.div>

                <span className="text-transparent bg-clip-text bg-gradient-to-b from-[#82d1aa] to-[#4a8566] cursor-default filter drop-shadow-[0_0_25px_rgba(98,174,136,0.5)]">
                    {t.hero.titleHighlight}
                </span>
            </span>
          </h1>

          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mb-10 leading-relaxed drop-shadow-md relative z-10">
            {t.hero.description}
          </p>

          <motion.a
            href="#contact"
            whileHover={{ scale: 1.05, boxShadow: "0 0 40px rgba(98,174,136,0.6)" }}
            whileTap={{ scale: 0.95 }}
            className="px-10 py-5 bg-brand text-dark-900 font-bold text-lg rounded-full shadow-[0_0_20px_rgba(98,174,136,0.4)] transition-all flex items-center gap-2 relative overflow-hidden group z-20"
          >
            <span className="relative z-10">{t.hero.cta}</span>
            <ArrowRight className="w-5 h-5 relative z-10 group-hover:translate-x-1 transition-transform" />
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
          </motion.a>
        </motion.div>
      </div>

      {/* 3. Trusted By Section (Bottom) */}
      <div className="w-full mt-auto pt-20 pb-10 relative z-10 border-t border-white/5 bg-gradient-to-t from-dark-900 via-dark-900/80 to-transparent">
        <div className="container mx-auto px-6 text-center">
            <p className="text-[10px] font-bold tracking-[0.3em] text-gray-600 mb-8 uppercase">
                {t.hero.trusted}
            </p>
            <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-40 hover:opacity-100 transition-opacity duration-500">
                {/* Simulated Logo Placeholders */}
                <div className="flex items-center gap-2 group cursor-default">
                    <div className="w-5 h-5 bg-gray-400 group-hover:bg-white transition-colors rounded-sm skew-x-12"></div>
                    <span className="font-bold text-lg font-sans text-gray-400 group-hover:text-white transition-colors">Layers</span>
                </div>
                <div className="flex items-center gap-2 group cursor-default">
                    <div className="w-5 h-5 border-2 border-gray-400 group-hover:border-white transition-colors rounded-full"></div>
                    <span className="font-bold text-lg font-sans text-gray-400 group-hover:text-white transition-colors">Quotient</span>
                </div>
                <div className="flex items-center gap-2 group cursor-default">
                    <div className="w-5 h-5 bg-gray-400 group-hover:bg-white transition-colors rounded-full"></div>
                    <span className="font-bold text-lg font-sans text-gray-400 group-hover:text-white transition-colors">Circooles</span>
                </div>
                <div className="flex items-center gap-2 group cursor-default">
                    <div className="w-5 h-5 bg-gray-400 group-hover:bg-white transition-colors rotate-45"></div>
                    <span className="font-bold text-lg font-sans text-gray-400 group-hover:text-white transition-colors">Hourglass</span>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
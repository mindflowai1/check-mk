import React from 'react';
import { motion } from 'framer-motion';
import { Video, Award, Target, Layout } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Solutions: React.FC = () => {
  const { t } = useLanguage();

  const solutions = [
    {
      title: t.solutions.items[0].title,
      desc: t.solutions.items[0].desc,
      icon: <Video className="w-6 h-6" />
    },
    {
      title: t.solutions.items[1].title,
      desc: t.solutions.items[1].desc,
      icon: <Target className="w-6 h-6" />
    },
    {
      title: t.solutions.items[2].title,
      desc: t.solutions.items[2].desc,
      icon: <Award className="w-6 h-6" />
    },
    {
      title: t.solutions.items[3].title,
      desc: t.solutions.items[3].desc,
      icon: <Layout className="w-6 h-6" />
    }
  ];

  return (
    <section id="solutions" className="py-24 bg-dark-900 relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-brand/5 to-transparent pointer-events-none"></div>

      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <span className="text-brand font-bold tracking-widest uppercase text-sm">{t.solutions.tag}</span>
          <h2 className="text-3xl md:text-5xl font-black text-white mt-4 mb-6">
            {t.solutions.title} <span className="text-brand">{t.solutions.titleHighlight}</span>
          </h2>
          <p className="text-gray-400">
            {t.solutions.description}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative h-min group rounded-2xl overflow-hidden"
          >
            <img 
              src="https://images.unsplash.com/photo-1590935216534-18e42f9606d5?q=80&w=1974&auto=format&fit=crop" 
              alt="Film set" 
              className="w-full h-full object-cover rounded-2xl opacity-80 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
            <div className="absolute bottom-6 left-6">
                <p className="text-brand font-bold mb-1">{t.solutions.imageTag}</p>
                <h3 className="text-2xl font-bold text-white">{t.solutions.imageTitle}</h3>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 gap-6">
            {solutions.map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-dark-800 p-6 rounded-xl border border-white/5 hover:border-brand/50 transition-colors flex items-start gap-4"
              >
                <div className="bg-brand/10 p-3 rounded-lg text-brand shrink-0">
                  {item.icon}
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">{item.title}</h4>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Solutions;